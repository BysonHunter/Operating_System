#!/usr/bin/python3
"""pr11-demo: bounded teaching HTTP service for practical work 11 (OS course).

The service is deliberately simple. Build 1.0-2 is produced from one template;
the build differs only in the constants below. It is NOT a real product.
"""
import argparse
import ipaddress
import json
import os
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit, parse_qs

UPSTREAM = '1.0'          # shown in the Server header
BUILD = '1.0-2'                # Debian version of the package
HAS_DEBUG = False          # /debug feature present in this build
HAS_UPLOAD = False        # optional upload feature present in this build
CONFIG = '/etc/pr11-demo/pr11-demo.conf'


def read_config(path):
    conf = {}
    with open(path, encoding='utf-8') as stream:
        for line in stream:
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            key, value = line.split('=', 1)
            conf[key.strip()] = value.strip()
    return conf


def emit(event, **fields):
    row = dict(event=event, build=BUILD, pid=os.getpid(), app_epoch=round(time.time(), 3))
    row.update(fields)
    print(json.dumps(row, ensure_ascii=True, sort_keys=True), flush=True)


def main():
    ap = argparse.ArgumentParser(description='pr11-demo teaching service')
    ap.add_argument('--bind', required=True)
    ap.add_argument('--port', type=int, required=True)
    ap.add_argument('--peer', required=True, help='the only remote address allowed (own Kali)')
    ap.add_argument('--run', required=True)
    ap.add_argument('--state', required=True, help='directory for runtime.json')
    ap.add_argument('--config', default=CONFIG)
    a = ap.parse_args()
    bind = str(ipaddress.IPv4Address(a.bind))
    peer = str(ipaddress.IPv4Address(a.peer))
    if not 22001 <= a.port <= 22027:
        raise SystemExit('teaching port must be 22001..22027')
    conf = read_config(a.config)
    debug = HAS_DEBUG and conf.get('debug', 'off') == 'on'
    upload = HAS_UPLOAD and conf.get('upload', 'off') == 'on'
    started = time.time()
    runtime = dict(build=BUILD, upstream=UPSTREAM, pid=os.getpid(), started_epoch=started, run=a.run,
                   bind=bind, port=a.port, peer=peer, debug_active=debug, upload_active=upload,
                   config=os.path.abspath(a.config))
    os.makedirs(a.state, exist_ok=True)
    tmp = os.path.join(a.state, 'runtime.json.tmp')
    with open(tmp, 'w', encoding='utf-8') as stream:
        json.dump(runtime, stream, indent=2, sort_keys=True)
    os.replace(tmp, os.path.join(a.state, 'runtime.json'))

    class Handler(BaseHTTPRequestHandler):
        server_version = 'PR11Demo/' + UPSTREAM

        def version_string(self):
            return self.server_version

        def log_message(self, fmt, *args):
            pass

        def reply(self, code, payload, body=True):
            data = json.dumps(payload, ensure_ascii=True, sort_keys=True).encode()
            self.send_response(code)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            if body:
                self.wfile.write(data)

        def handle_any(self, body):
            part = urlsplit(self.path)
            rid = parse_qs(part.query).get('rid', [''])[0][:80]
            client = self.client_address[0]
            if client not in (peer, bind, '127.0.0.1'):
                code = 403
                self.reply(code, dict(error='only own teaching peer'), body)
            elif part.path == '/':
                code = 200
                self.reply(code, dict(service='pr11-demo', run=a.run), body)
            elif part.path == '/health':
                code = 200
                self.reply(code, dict(status='ok', run=a.run), body)
            elif part.path == '/debug' and debug:
                code = 200
                self.reply(code, dict(debug=True, config=read_config(a.config)), body)
            else:
                code = 404
                self.reply(code, dict(error='not found'), body)
            emit('HTTP_REQUEST', method=self.command, path=part.path, rid=rid, peer=client, http_status=code)

        def do_GET(self):
            self.handle_any(True)

        def do_HEAD(self):
            self.handle_any(False)

    class Server(HTTPServer):
        def handle_error(self, request, client_address):
            # malformed probes (e.g. from a version scan) are recorded compactly instead of a traceback
            emit('CONNECTION_ERROR', peer=client_address[0])

    http = Server((bind, a.port), Handler)
    emit('SERVER_READY', upstream=UPSTREAM, bind=bind, port=a.port, allowed_peer=peer,
         debug_active=debug, upload_active=upload, run=a.run)
    try:
        http.serve_forever(poll_interval=0.3)
    finally:
        http.server_close()


if __name__ == '__main__':
    main()
